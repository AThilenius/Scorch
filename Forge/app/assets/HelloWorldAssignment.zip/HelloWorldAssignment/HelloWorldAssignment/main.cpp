//
//  main.cpp
//  Anvil
//
//  Created by Forge on 11/13/14.
//  Copyright (c) 2014 Scorch. All rights reserved.
//

#include "Anvil.h"

using namespace AnvilAPI;

int main() {
    
}